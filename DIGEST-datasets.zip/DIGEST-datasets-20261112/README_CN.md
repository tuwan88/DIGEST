# DIGEST 四数据集包

本包整理了此前公开项目包登记的四套数据：OGB-molhiv、OGB-molpcba、OGB-code2 和 IMDB。包含图文件、标签映射、图对划分、reference GED 与匹配标注，以及必要的解包和数据准备工具。

## 内容与版本

| 数据集 | 标签 | 训练 / 验证 / 测试 | 数据版本 |
| --- | --- | --- | --- |
| OGB-molhiv | 55 类原子类型 | 120,000 / 15,000 / 15,000 图对 | 论文所选 molhiv 模型对应的 atomic55 版本 |
| OGB-molpcba | 44 类原子类型 | 120,000 / 15,000 / 15,000 图对 | search-only，reference 取 A* 与 DFS 各 k=10,000 的较小值 |
| OGB-code2 | 97 类 AST 节点类型 | 120,000 / 15,000 / 15,000 图对 | AST97 版本；另附固定的 1,500 对验证子集 |
| IMDB | 无节点标签，单类别 | 1,200 张训练来源图；固定 30,000 测试图对 | 原始图与 TaGED 标注，以及保留的真实/合成测试图对 |

molhiv 保留与论文模型对应的 reference；较晚的 molhiv search-only reference 是另一版本，本包没有将其混入。molpcba 使用新的 search-only 版本。reference GED 是保存的匹配成本/搜索结果，具体标注保留在原始记录中。

IMDB 附带 `metadata/imdb_graph_split.json`：按 seed=20261021、图规模分层，将 1,200 张来源图分成 1,080 张训练图和 120 张验证图。原训练流程从中构造 179,700 个训练图对和 12,000 个验证图对；大图验证包含动态生成的合成图。训练来源图、TaGED 标注和固定测试集均在包内。native 目录中的两份同名图是原始兼容副本，保留其原有布局。

## 解包

需要 Python 3.9 或更新版本，无需安装额外 Python 包。

先解压外层 ZIP，再进入 `DIGEST-datasets-20261112` 文件夹：

```bash
# 检查四个数据资产的 SHA256
python tools/unpack.py --verify-only

# 解开全部数据；output 应为新目录或空目录
python tools/unpack.py --output extracted

# 也可只解开某个数据集
python tools/unpack.py --dataset molpcba --output molpcba-data
```

也可以用支持 TAR/GZIP 的解压工具解开 `archives/data-*.tar.gz`。四个资产沿用原包字节，内部图路径、图对顺序与标签映射均保持原样。

解包后主要路径：

```text
extracted/artifacts/data/
  test/
    ogbg-molhiv/
    ogbg-molpcba/
    ogbg-code2-ast97-ref/
    IMDB/
  train/
    ogbg-molhiv/
    ogbg-molpcba/
    ogbg-code2-ast97-ref/
  code2-validation/ogbg-code2-ast97-ref/
  imdb_native/json_data/IMDB/
```

## 数据格式

- `benchmark_train_pairs.jsonl`、`benchmark_val_pairs.jsonl`、`benchmark_test_pairs.jsonl`：每行一个图对，常用字段为 `graph_1`、`graph_2`、`ged`、`node_mapping_pairs`。图路径相对于该 JSONL 所在的数据集目录。重复图对按原始出现顺序保留。
- 分子数据和 code2 的 `solver_graphs/*` 是文本图文件：首行 `n m L`，之后 n 行为节点 ID 与节点标签，再之后 m 行为无向边端点。
- IMDB 测试图为 JSON，含节点数、边及图 ID 等字段；其测试集包含真实图和合成扰动图。
- `labels.json` 保存节点标签映射，应与所属数据目录一起使用。
- IMDB 的 `TaGED.json` 保存原图对 GED、成本分项和匹配。`imdb_native/json_data/IMDB/train/graphs/` 是训练程序读取的来源图目录。

## code2 固定验证子集

完整训练资产含 15,000 对验证数据，模型选择使用的固定子集含 1,500 对。子集路径中的 `benchmark_test_pairs.jsonl` 是原评估加载器使用的文件名，数据来自验证集。

以下工具会保留训练标注与固定子集顺序，并生成 `train/val` 形式的数据视图：

```bash
python tools/prepare_code2_training.py \
  --training-root extracted/artifacts/data/train/ogbg-code2-ast97-ref \
  --validation-root extracted/artifacts/data/code2-validation/ogbg-code2-ast97-ref \
  --output code2-training-view
```

PowerShell 中可将该命令写成一行。

## 清单与检查

- `metadata/asset_manifest.json`：四份数据资产的 SHA256、压缩大小、文件数和解包数据大小。
- `metadata/datasets.json`：所选数据版本及目录入口。
- `metadata/dataset_layout.json`：各 split 图对数量与标注文件哈希。
- `metadata/test_data_trees.json`：四个完整测试目录的文件树哈希。
- `metadata/*_members.jsonl.gz`：每个数据文件的相对路径、大小和 SHA256。
- `metadata/VERIFICATION.json`：本次打包的完整读取、文件哈希、图对引用和划分核对结果。
- `SHA256SUMS.txt`：本包文件校验清单。

数据共 345,877 个文件，文件内容合计约 500 MiB；大量小文件解包后会产生额外文件系统开销。第三方来源声明保留在 `provenance/THIRD_PARTY_NOTICES.md`。本包是本地整理产物。
