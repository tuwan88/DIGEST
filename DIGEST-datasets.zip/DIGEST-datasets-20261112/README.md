# DIGEST datasets

Data-only collection of the four dataset assets registered in the DIGEST release: molhiv, molpcba, code2, and IMDB. Graphs, pair order, labels, reference costs, and supervised mappings retain their original bytes. Model weights and experiment outputs are not part of this package.

| Dataset | Labels | Train / validation / test pairs | Revision |
| --- | --- | --- | --- |
| OGB-molhiv | 55 atom types | 120,000 / 15,000 / 15,000 | Selected paper model's atomic55 input |
| OGB-molpcba | 44 atom types | 120,000 / 15,000 / 15,000 | Search-only min(A* k10,000, DFS k10,000) |
| OGB-code2 | 97 AST types | 120,000 / 15,000 / 15,000 | Preserved AST97 input; fixed validation subset of 1,500 pairs also included |
| IMDB | Unlabeled | Native source graphs plus fixed 30,000 test pairs | Native TaGED annotations and real/synthetic evaluation graphs |

Molhiv retains its model-compatible reference; the later molhiv search-only revision is a separate dataset version. Molpcba uses the updated search-only reference. Reference costs are stored matching/search results.

## Use

Unzip this delivery and enter its root directory. Python 3.9+ is sufficient; no external packages are needed.

```bash
python tools/unpack.py --verify-only
python tools/unpack.py --output extracted
# Or select one dataset and a new output directory:
python tools/unpack.py --dataset molpcba --output molpcba-data
```

The output directory must be new or empty. Archives can also be opened with a TAR/GZIP extraction tool.

Evaluation datasets are under `extracted/artifacts/data/test/<dataset>/`. Molecular and code2 training inputs are under `extracted/artifacts/data/train/<dataset>/`. Dataset names are `ogbg-molhiv`, `ogbg-molpcba`, `ogbg-code2-ast97-ref`, and `IMDB`.

Pair manifests are JSONL files named `benchmark_{train,val,test}_pairs.jsonl`. `graph_1` and `graph_2` are relative to the manifest's dataset directory; `ged` and `node_mapping_pairs` retain the annotated cost and matching. Repeated graph pairs retain their original order. Molecular/code2 `solver_graphs/*` files are text: header `n m L`, followed by n node-ID/label rows and m undirected edges. IMDB evaluation graphs are JSON. Keep each `labels.json` with its own dataset directory.

## Special split layouts

IMDB native data is at `extracted/artifacts/data/imdb_native/json_data/IMDB/`, containing `train/graphs/*.json` and `TaGED.json`. `metadata/imdb_graph_split.json` records the exact 1,080/120 graph holdout obtained from 1,200 source graphs with seed 20261021 and size stratification. The original training loader constructs 179,700 training pairs and 12,000 validation pairs, including generated large-graph validation examples. The native TAR preserves duplicate compatibility copies under `train/*.json`.

Code2's fixed model-selection validation subset is under `extracted/artifacts/data/code2-validation/ogbg-code2-ast97-ref/`. Its `benchmark_test_pairs.jsonl` filename is an evaluation-loader alias for validation examples. To construct the training view:

```bash
python tools/prepare_code2_training.py \
  --training-root extracted/artifacts/data/train/ogbg-code2-ast97-ref \
  --validation-root extracted/artifacts/data/code2-validation/ogbg-code2-ast97-ref \
  --output code2-training-view
```

## Verification and provenance

`metadata/asset_manifest.json` lists SHA256, sizes and file counts. `metadata/VERIFICATION.json` records this package's archive reads, per-file hashes, split counts and hashes, graph-reference checks, and complete evaluation-tree hashes. Compressed `*_members.jsonl.gz` indexes list every data file. `SHA256SUMS.txt` covers the packaged files.

The assets contain 345,877 files totaling 523,771,553 bytes before filesystem overhead. Existing third-party notices are retained under `provenance/`. See `README_CN.md` for the Chinese guide.
