# Third-party notices and unresolved permissions

This file records reviewed upstream information as of 2026-11-11. It does not grant a project-wide license to DIGEST, its weights, or its original annotations, and it does not establish permission for an unidentified third-party snapshot. The authorized owner must supply the license for original project contributions separately.

## OGB molecular data

The official OGB graph-property dataset page identifies `ogbg-molhiv` and `ogbg-molpcba` as MIT-licensed datasets. They are derived from MoleculeNet; DIGEST further selects atom types and undirected connectivity for its graph edit task. Redistribution of the OGB-derived molecular graphs must preserve the OGB copyright and permission notice. A separate asset must also identify DIGEST's transformations and annotation revision.

Sources: [OGB dataset descriptions](https://ogb.stanford.edu/docs/graphprop/), [OGB license](https://github.com/snap-stanford/ogb/blob/master/LICENSE), [MoleculeNet paper](https://doi.org/10.1039/C7SC02664A).

The upstream OGB notice is reproduced below for the material distributed under that notice:

```text
MIT License

Copyright (c) 2019 OGB Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

This notice is not a representation that every additional PubChem, NCI, or other raw-source record has been separately reviewed. The approved molecular asset scope is the identified OGB-derived graph material. Adding unrelated upstream metadata or raw-source collections requires a review of those additions. PubChem itself notes that some contributed information may carry copyright restrictions: [PubChem submission policy](https://pubchem.ncbi.nlm.nih.gov/pcfe/docs/markdown/data-submission-policy.md).

## OGB code2 and CodeSearchNet

OGB labels its `ogbg-code2` graph dataset MIT and identifies CodeSearchNet as its source. CodeSearchNet's own instructions explicitly separate the MIT license of its tooling/documentation from the per-source licenses of the code used as data. It supplies those source licenses in per-language `_licenses.pkl` files.

Sources: [OGB code2 description](https://ogb.stanford.edu/docs/graphprop/), [CodeSearchNet license instructions](https://github.com/github/CodeSearchNet#licenses).

Release status: **per-source license and provenance review required**. This package does not authorize a mirror of the code2 source or derived graph corpus. Retain source license/attribution records and trace the selected methods/graphs, or obtain a documented clarification covering the intended derived artifact. A dataset or code repository's MIT badge alone is not used here to override individual source licenses.

## IMDB-derived graph benchmark

The inspected historical records identify a legacy graph archive and a GedGNN-style fixed-pair reconstruction, including synthetic graph perturbations. They do not identify a verified upstream data release and applicable redistribution terms.

Release status: **restricted provenance review**. No public redistribution permission for those data is asserted. The reconstruction metadata is described in [`docs/DATASETS.md`](docs/DATASETS.md). The current IMDb terms restrict use and republication of its official non-commercial data; this file neither assumes that those current terms are a complete account of the historical graph artifact nor treats absence of movie titles as a license grant.

Sources: [GedGNN project](https://github.com/ChengzhiPiao/GEDGNN), [TUDataset IMDB entries](https://chrsmrrs.github.io/datasets/docs/datasets/), [IMDb official licensing explanation](https://help.imdb.com/article/imdb/general-information/can-i-use-imdb-data-in-my-software/G5JTRESSHJBBHTGX).

## Third-party code and trained weights

The data review above is not a complete source-code dependency audit. Before distributing any vendored baseline, solver, extension, or compiled binary, the release inventory must identify the exact source revision, modifications, copyright notices and applicable license. Public availability of a repository is not used as a substitute for an explicit redistribution grant.

Training a checkpoint on a named dataset does not, by itself, establish that the checkpoint shares the dataset license. Each included checkpoint needs an authorized owner declaration and metadata binding it to its actual training revision. Imported third-party checkpoints require their own provenance and permission review. No project or model license is selected by this notice.
