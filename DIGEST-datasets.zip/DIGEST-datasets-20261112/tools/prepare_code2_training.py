"""Build a new code2 training view using the exact fixed validation subset.

Inputs are dataset directories, not their parents. Only listed training and
validation graphs are copied. No graph, GED, mapping, or row order is changed.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sys

from verify_dataset import file_fingerprint, is_linklike
from verify_release import contained_path, load_json, relative_parts


def manifest_path(root, split):
    for relative in (f"benchmark_{split}_pairs.jsonl", f"{split}/pairs.jsonl"):
        path = contained_path(root, relative)
        if path.is_file():
            return path
    raise FileNotFoundError(f"Missing {split} pair manifest")


def read_rows(path):
    rows = []
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for number, line in enumerate(stream, 1):
            digest.update(line)
            size += len(line)
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict):
                raise ValueError(f"Pair row {number} must be an object")
            ged = row.get("ged")
            if not isinstance(ged, (int, float)) or isinstance(ged, bool) or not math.isfinite(ged) or ged < 0:
                raise ValueError(f"Invalid GED at row {number}")
            if not row.get("node_mapping_pairs"):
                raise ValueError(f"Missing original supervised matching at row {number}; no mapping will be generated")
            rows.append(row)
    if not rows:
        raise ValueError("Empty pair manifest")
    return rows, {"sha256": digest.hexdigest(), "bytes": size}


def graph_key(row, side, split):
    key = row.get("graph_" + str(side))
    if key is None:
        identifier = row.get("new_query_gid" if side == 1 else "new_db_gid")
        if type(identifier) is not int or identifier < 0:
            raise ValueError("Missing graph path or nonnegative integer fallback ID")
        key = f"{split}/graphs/{identifier}.json"
    relative_parts(key)
    return key


def copy_exact(source, target, mode):
    if not source.is_file() or is_linklike(source):
        raise ValueError("Input must be a regular, non-symlink file: " + source.name)
    expected = file_fingerprint(source)
    if target.exists():
        if file_fingerprint(target) != expected:
            raise ValueError("Different source files collide at output: " + target.name)
        return expected
    target.parent.mkdir(parents=True, exist_ok=True)
    if mode == "hardlink":
        os.link(source, target)
    else:
        shutil.copy2(source, target)
    if file_fingerprint(target) != expected:
        raise ValueError("Copied file differs from source: " + target.name)
    return expected


def prepare(training_root, validation_root, output, mode, expected_train, expected_val):
    if is_linklike(training_root) or is_linklike(validation_root):
        raise ValueError("Input roots must not be symbolic links or reparse points")
    training_root, validation_root, output = training_root.resolve(), validation_root.resolve(), output.resolve()
    if output.exists():
        raise FileExistsError("Output must be a new directory")
    if output.is_relative_to(training_root) or output.is_relative_to(validation_root):
        raise ValueError("Output must be outside both input directories")
    train_manifest = manifest_path(training_root, "train")
    subset_manifest = manifest_path(validation_root, "test")
    labels = contained_path(training_root, "labels.json")
    if not labels.is_file():
        raise FileNotFoundError("Training labels.json is required")
    train_rows, train_fingerprint = read_rows(train_manifest)
    subset_rows, subset_fingerprint = read_rows(subset_manifest)
    if len(train_rows) != expected_train or len(subset_rows) != expected_val:
        raise ValueError(f"Expected {expected_train}/{expected_val} train/validation pairs; got {len(train_rows)}/{len(subset_rows)}")
    subset_labels = contained_path(validation_root, "labels.json")
    if subset_labels.is_file() and load_json(labels) != load_json(subset_labels):
        raise ValueError("Training and validation label mappings differ")
    copies, origins, converted = {}, {}, []
    for row in train_rows:
        if row.get("benchmark_split", "train") != "train":
            raise ValueError("Training manifest contains a non-training row")
        for side in (1, 2):
            key = graph_key(row, side, "train")
            if relative_parts(key)[0] != "train":
                raise ValueError("Training rows must reference train/ graph paths")
            source = contained_path(training_root, key)
            copies.setdefault(key, source)
            origins.setdefault(key, {"source": "training", "source_path": key})
    for row in subset_rows:
        if row.get("benchmark_split", "test") not in {"test", "val", "validation"}:
            raise ValueError("Validation subset has an unexpected split")
        result = dict(row)
        for side in (1, 2):
            key = graph_key(row, side, "test")
            parts = relative_parts(key)
            if parts[0] not in {"test", "val", "validation"} or len(parts) < 2:
                raise ValueError("Validation subset graph must have a test/ or val/ prefix")
            target_key = "/".join(["val", *parts[1:]])
            source = contained_path(validation_root, key)
            if target_key in copies and copies[target_key] != source:
                if file_fingerprint(copies[target_key]) != file_fingerprint(source):
                    raise ValueError("Distinct validation graphs collide after prefix conversion")
            copies.setdefault(target_key, source)
            origins.setdefault(target_key, {"source": "fixed_validation_subset", "source_path": key})
            result["graph_" + str(side)] = target_key
        result["benchmark_split"] = "val"
        converted.append(result)
    for source in copies.values():
        if not source.is_file():
            raise FileNotFoundError("Referenced graph is missing: " + source.name)
    source_records = {"training_manifest": train_fingerprint,
                      "fixed_validation_manifest": subset_fingerprint,
                      "labels": file_fingerprint(labels)}
    # The complete source selection is checked before the destination is created.
    output.mkdir(parents=True)
    file_records = []
    try:
        if copy_exact(labels, output / "labels.json", mode) != source_records["labels"]:
            raise ValueError("Label file changed during preparation")
        if copy_exact(train_manifest, output / "benchmark_train_pairs.jsonl", mode) != train_fingerprint:
            raise ValueError("Training manifest changed during preparation")
        for name in sorted(copies):
            fingerprint = copy_exact(copies[name], output / name, mode)
            file_records.append({"path": name, **origins[name], **fingerprint})
        val_path = output / "benchmark_val_pairs.jsonl"
        with val_path.open("w", encoding="utf-8", newline="\n") as stream:
            for row in converted:
                stream.write(json.dumps(row, separators=(",", ":"), ensure_ascii=False, allow_nan=False) + "\n")
        mapping_path = output / "graph_path_mapping.jsonl"
        with mapping_path.open("w", encoding="utf-8", newline="\n") as stream:
            for row in file_records:
                stream.write(json.dumps(row, separators=(",", ":"), ensure_ascii=False) + "\n")
        provenance = {"status": "PASS", "dataset": "ogbg-code2-ast97-ref", "mode": mode,
                      "train_pairs": len(train_rows), "validation_pairs": len(converted),
                      "source_fingerprints": source_records,
                      "training_manifest_byte_preserved": True,
                      "validation_row_order_preserved": True,
                      "validation_edits": ["graph path prefix renamed to val when necessary", "benchmark_split set to val"],
                      "ged_and_node_mappings_preserved": True,
                      "graph_bytes_preserved": True, "sampling_performed": False,
                      "files": {"benchmark_train_pairs.jsonl": file_fingerprint(output / "benchmark_train_pairs.jsonl"),
                                "benchmark_val_pairs.jsonl": file_fingerprint(val_path),
                                "graph_path_mapping.jsonl": file_fingerprint(mapping_path),
                                "labels.json": file_fingerprint(output / "labels.json")}}
        (output / "PREPARATION.json").write_text(json.dumps(provenance, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        return provenance
    except Exception:
        # Keep evidence for diagnosis; a partial directory cannot masquerade as ready.
        (output / "PREPARATION_FAILED.txt").write_text("Preparation failed. Do not train from this directory.\n", encoding="utf-8")
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--training-root", type=Path, required=True)
    parser.add_argument("--validation-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("copy", "hardlink"), default="copy")
    parser.add_argument("--expected-train-pairs", type=int, default=120000)
    parser.add_argument("--expected-val-pairs", type=int, default=1500)
    options = parser.parse_args(argv)
    try:
        if options.expected_train_pairs <= 0 or options.expected_val_pairs <= 0:
            raise ValueError("Expected pair counts must be positive")
        report = prepare(options.training_root, options.validation_root, options.output,
                         options.mode, options.expected_train_pairs, options.expected_val_pairs)
    except (OSError, ValueError, RuntimeError) as error:
        print(json.dumps({"status": "FAIL", "error": str(error)}))
        return 1
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
