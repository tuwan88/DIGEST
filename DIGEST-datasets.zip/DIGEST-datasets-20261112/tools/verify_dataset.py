"""Verify every file in the dataset tree selected by an evaluation config."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

from verify_release import SHA256, contained_path, load_json, relative_parts


ROOT = Path(__file__).resolve().parents[1]


def is_linklike(path):
    metadata = path.lstat()
    return stat.S_ISLNK(metadata.st_mode) or bool(getattr(metadata, "st_file_attributes", 0) & 0x400)


def file_fingerprint(path):
    before = path.stat()
    hasher = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
            size += len(chunk)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino) or size != after.st_size:
        raise ValueError("File changed while hashing: " + path.name)
    return {"sha256": hasher.hexdigest(), "bytes": size}


def tree_fingerprint(root):
    if is_linklike(root):
        raise ValueError("Dataset root must not be a symbolic link or reparse point")
    root = root.resolve()
    if not root.is_dir():
        raise ValueError("Dataset directory does not exist")
    names = []
    identities = set()

    def walk_error(error):
        raise error

    for directory, dirs, files in os.walk(root, followlinks=False, onerror=walk_error):
        for name in dirs + files:
            path = Path(directory) / name
            relative = path.relative_to(root).as_posix()
            relative_parts(relative)
            contained_path(root, relative)
            metadata = path.lstat()
            if is_linklike(path):
                raise ValueError("Symbolic link or reparse point in dataset: " + relative)
            if not stat.S_ISREG(metadata.st_mode) and not stat.S_ISDIR(metadata.st_mode):
                raise ValueError("Non-regular entry in dataset: " + relative)
            if name in files:
                if not stat.S_ISREG(metadata.st_mode):
                    raise ValueError("Expected regular file: " + relative)
                if relative.casefold() in identities:
                    raise ValueError("Case-colliding file paths: " + relative)
                identities.add(relative.casefold())
                names.append(relative)
    if not names:
        raise ValueError("Dataset tree is empty")
    tree = hashlib.sha256()
    total_bytes = 0
    for name in sorted(names):
        record = file_fingerprint(contained_path(root, name))
        tree.update((name + "\0" + record["sha256"] + "\0" + str(record["bytes"]) + "\n").encode("utf-8"))
        total_bytes += record["bytes"]
    return {"files": len(names), "bytes": total_bytes, "tree_sha256": tree.hexdigest()}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, default=ROOT / "artifacts/data/test")
    options = parser.parse_args(argv)
    report = {"status": "FAIL"}
    try:
        config = load_json(options.config)
        if not isinstance(config, dict):
            raise ValueError("Config must be a JSON object")
        dataset = config.get("dataset")
        if len(relative_parts(dataset)) != 1:
            raise ValueError("dataset must be one safe directory name")
        expected = config.get("data_tree_sha256")
        if not isinstance(expected, str) or not SHA256.fullmatch(expected):
            raise ValueError("Config requires a 64-digit data_tree_sha256")
        if is_linklike(options.data_root):
            raise ValueError("data-root must not be a symbolic link or reparse point")
        directory = contained_path(options.data_root.resolve(), dataset)
        report.update(dataset=dataset, expected_tree_sha256=expected.lower())
        report.update(tree_fingerprint(directory))
        if report["tree_sha256"] != expected.lower():
            raise ValueError("Dataset tree SHA256 mismatch")
        report["status"] = "PASS"
    except (OSError, ValueError, RuntimeError) as error:
        report["error"] = str(error)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
