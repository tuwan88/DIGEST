"""Verify release checksums; --all also verifies separately delivered assets.

CHECKSUMS.json is {relative_path: {"sha256": hex_digest, "bytes": integer}}.
The asset manifest is {"artifacts": [{"path": relative_path, "sha256":
hex_digest, "bytes": integer, "kind": string, "distribution": string}]}.
Missing separate_asset/remote/expected_remote_asset files are reported as
expected_remote_assets, but still make --all fail. No files are extracted.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import stat
import sys
import zipfile


ROOT = Path(__file__).resolve().parents[1]
REMOTE_DISTRIBUTIONS = {"separate_asset", "remote", "expected_remote_asset"}
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=unique_object)


def relative_parts(value):
    """Accept portable relative paths, including when checking ZIP members."""
    if not isinstance(value, str) or not value or "\x00" in value:
        raise ValueError("Path must be a nonempty string without NUL")
    if "\\" in value or ":" in value:
        raise ValueError("Use relative POSIX paths without backslashes or colons")
    if PurePosixPath(value).is_absolute() or PureWindowsPath(value).anchor:
        raise ValueError("Absolute or drive-qualified path")
    parts = value.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Empty, dot, or parent path component")
    if any(part.endswith((" ", ".")) or PureWindowsPath(part).is_reserved() for part in parts):
        raise ValueError("Windows-reserved or ambiguously normalized path component")
    return parts


def contained_path(root, value):
    parts = relative_parts(value)
    candidate = root.joinpath(*parts)
    # Resolve junctions and symlinks before any file is opened.
    resolved = candidate.resolve()
    if not resolved.is_relative_to(root):
        raise ValueError("Path resolves outside the selected root")
    current = root
    for part in parts:
        current = current / part
        if current.is_symlink():
            raise ValueError("Manifest entries must not traverse symbolic links")
    return candidate


def check_zip_members(path):
    """Reject unsafe ZIP member names and symlinks without extracting them."""
    seen = set()
    with zipfile.ZipFile(path) as archive:
        for member in archive.infolist():
            name = member.filename[:-1] if member.is_dir() else member.filename
            relative_parts(name)
            if name in seen:
                raise ValueError("Duplicate ZIP member: " + name)
            seen.add(name)
            if stat.S_ISLNK(member.external_attr >> 16):
                raise ValueError("ZIP symbolic link: " + name)


def validate_record(path, record):
    relative_parts(path)
    if not isinstance(record, dict):
        raise ValueError("Each entry must contain sha256 and bytes")
    checksum = record.get("sha256")
    size = record.get("bytes")
    if not isinstance(checksum, str) or not SHA256.fullmatch(checksum):
        raise ValueError("sha256 must contain exactly 64 hexadecimal digits")
    if type(size) is not int or size < 0:
        raise ValueError("bytes must be a nonnegative integer")


def verify_entries(entries, root, report, category):
    seen = set()
    for name, record in entries:
        try:
            validate_record(name, record)
            # Case-folding also detects collisions when a package moves to Windows.
            identity = name.casefold()
            if identity in seen:
                raise ValueError("Duplicate or case-colliding manifest path")
            seen.add(identity)
            path = contained_path(root, name)
            if not path.exists():
                target = ("expected_remote_assets" if category == "asset" and
                          record.get("distribution") in REMOTE_DISTRIBUTIONS
                          else "missing_files")
                report[target].append({"path": name, "category": category})
                continue
            if not path.is_file():
                raise ValueError("Entry is not a regular file")
            size = path.stat().st_size
            if size != record["bytes"]:
                raise ValueError(f"Size mismatch: expected {record['bytes']}, got {size}")
            hasher = hashlib.sha256()
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    hasher.update(chunk)
            if hasher.hexdigest() != record["sha256"].lower():
                raise ValueError("SHA256 mismatch")
            if path.suffix.lower() == ".zip":
                check_zip_members(path)
            report["verified_files"].append({"path": name, "category": category, "bytes": size})
        except (OSError, ValueError, RuntimeError, zipfile.BadZipFile) as error:
            report["errors"].append({"path": name, "category": category, "error": str(error)})


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-root", type=Path, default=ROOT)
    parser.add_argument("--checksums", type=Path, help="Default: RELEASE_ROOT/CHECKSUMS.json")
    parser.add_argument("--artifact-manifest", type=Path,
                        help="Default: RELEASE_ROOT/data/asset_manifest.json; checked with --all")
    parser.add_argument("--assets-root", type=Path, help="Default: RELEASE_ROOT")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--code-only", action="store_true", help="Verify CHECKSUMS.json only (default)")
    mode.add_argument("--all", action="store_true", help="Verify code and every declared asset")
    options = parser.parse_args(argv)
    root = options.release_root.resolve()
    assets_root = (options.assets_root or root).resolve()
    report = {"mode": "all" if options.all else "code-only", "verified_files": [],
              "expected_remote_assets": [], "missing_files": [], "errors": [],
              "assets_checked": bool(options.all)}
    manifests = [("code", options.checksums or root / "CHECKSUMS.json", root)]
    if options.all:
        manifests.append(("asset", options.artifact_manifest or root / "data/asset_manifest.json", assets_root))
    for category, manifest, base in manifests:
        try:
            if not base.is_dir():
                raise ValueError("Selected verification root is not a directory")
            data = load_json(manifest)
            if category == "code":
                if not isinstance(data, dict) or not data:
                    raise ValueError("CHECKSUMS.json must be a nonempty path-to-metadata object")
                entries = list(data.items())
            else:
                if not isinstance(data, dict) or not isinstance(data.get("artifacts"), list):
                    raise ValueError("Asset manifest must contain an artifacts array")
                entries = []
                for item in data["artifacts"]:
                    if not isinstance(item, dict) or not isinstance(item.get("kind"), str) or not isinstance(item.get("distribution"), str):
                        raise ValueError("Asset entries require path, sha256, bytes, kind, and distribution")
                    entries.append((item.get("path"), item))
            verify_entries(entries, base, report, category)
        except (OSError, ValueError, RuntimeError) as error:
            report["errors"].append({"category": category, "error": str(error)})
    failed = bool(report["errors"] or report["missing_files"] or report["expected_remote_assets"])
    report["status"] = "FAIL" if failed else "PASS"
    report["verified_file_count"] = len(report["verified_files"])
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
