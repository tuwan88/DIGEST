"""Verify and unpack the selected DIGEST data assets with Python 3.9+."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_parts(name):
    p = PurePosixPath(name)
    if not name or p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name:
        raise ValueError('Invalid archive path: ' + name)
    return p.parts


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dataset', choices=['all', 'molhiv', 'molpcba', 'code2', 'imdb'], default='all')
    ap.add_argument('--verify-only', action='store_true')
    ap.add_argument('--output', type=Path, help='A new or empty destination directory')
    args = ap.parse_args()
    if not args.verify_only and args.output is None:
        ap.error('--output is required unless --verify-only is used')
    manifest = json.loads((ROOT / 'metadata/asset_manifest.json').read_text(encoding='utf-8'))
    assets = [a for a in manifest['artifacts'] if args.dataset == 'all' or a['dataset'] == args.dataset]
    for a in assets:
        path = ROOT.joinpath(*safe_parts(a['path']))
        if path.stat().st_size != a['bytes'] or sha256(path) != a['sha256']:
            raise ValueError('Checksum mismatch: ' + a['path'])
        print('Verified:', a['path'], flush=True)
    if args.verify_only:
        return
    destination = args.output.expanduser()
    if destination.is_symlink():
        raise ValueError('Destination must not be a symbolic link')
    if destination.exists() and (not destination.is_dir() or any(destination.iterdir())):
        raise ValueError('Use a new or empty destination directory')
    destination.mkdir(parents=True, exist_ok=True)
    destination = destination.resolve()
    files = 0
    for a in assets:
        with tarfile.open(ROOT / a['path'], 'r|gz') as archive:
            for member in archive:
                target = destination.joinpath(*safe_parts(member.name))
                if not target.resolve().is_relative_to(destination):
                    raise ValueError('Archive path escapes destination')
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(member) as source, target.open('xb') as out:
                        shutil.copyfileobj(source, out)
                    files += 1
                else:
                    raise ValueError('Unsupported archive entry: ' + member.name)
        print('Unpacked:', a['dataset'], flush=True)
    print('Complete:', files, 'files in', destination)


if __name__ == '__main__':
    main()
